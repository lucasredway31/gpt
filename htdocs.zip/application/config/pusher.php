<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['app_id'] = '1770984';
$config['key'] = '9409e590e6cabd54fe62';
$config['secret'] = 'd21f8d34c1235e582337';
$config['cluster'] = 'eu';
$config['useTLS'] = true;
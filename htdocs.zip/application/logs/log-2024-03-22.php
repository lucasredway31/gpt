<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-22 12:35:28 --> Could not find the language line "404"
ERROR - 2024-03-22 12:35:28 --> Could not find the language line "404"
ERROR - 2024-03-22 12:41:18 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 219
ERROR - 2024-03-22 12:41:32 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 219
ERROR - 2024-03-22 12:42:18 --> Severity: error --> Exception: syntax error, unexpected token ".", expecting "elseif" or "else" or "endif" C:\xampp\htdocs\application\views\theme\default\movie_player.php 219
ERROR - 2024-03-22 12:42:21 --> Severity: error --> Exception: syntax error, unexpected token ".", expecting "elseif" or "else" or "endif" C:\xampp\htdocs\application\views\theme\default\movie_player.php 219
ERROR - 2024-03-22 12:42:46 --> Could not find the language line "404"
ERROR - 2024-03-22 12:42:46 --> Could not find the language line "404"
ERROR - 2024-03-22 12:43:42 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:45:06 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:45:19 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:45:20 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:45:21 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:45:21 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:46:19 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:48:31 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:48:51 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 12:49:10 --> Could not find the language line "404"
ERROR - 2024-03-22 12:49:10 --> Could not find the language line "404"
ERROR - 2024-03-22 12:51:15 --> Could not find the language line "404"
ERROR - 2024-03-22 12:51:15 --> Could not find the language line "404"
ERROR - 2024-03-22 12:51:30 --> Could not find the language line "404"
ERROR - 2024-03-22 12:51:30 --> Could not find the language line "404"
ERROR - 2024-03-22 12:55:35 --> Could not find the language line "404"
ERROR - 2024-03-22 12:55:35 --> Could not find the language line "404"
ERROR - 2024-03-22 12:59:22 --> Could not find the language line "404"
ERROR - 2024-03-22 12:59:22 --> Could not find the language line "404"
ERROR - 2024-03-22 13:16:34 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:17:32 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:19:23 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:19:52 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:20:07 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:21:27 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:22:21 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:26:14 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220
ERROR - 2024-03-22 13:26:20 --> Severity: Warning --> Undefined variable $movie_id C:\xampp\htdocs\application\views\theme\default\movie_player.php 220

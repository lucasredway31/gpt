the script is complete by default

SOME LANG LINES MISSING I,VE BEEN ADDED AT THE TOP

-> application/language/english/site_lang.php

// START EXTRA
$lang["add_channel"] = "Add Channel";
$lang["channel_name"] = "Channel Name";
$lang["paid"] = "Paid";
// END EXTRA
videojs.addLanguage('en', {
  "Seek forward {{seconds}} seconds": "Seek forward {{seconds}} seconds",
  "Seek back {{seconds}} seconds": "Seek back {{seconds}} seconds"
});
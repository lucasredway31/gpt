videojs.addLanguage('ru', {
  "Share": "Поделиться",
  "Direct Link": "Прямая ссылка",
  "Embed Code": "Код для встраивания плеера",
  "Copy": "Скопировать",
  "Copied": "Скопировано"
});